<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="Main.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta charset="utf-8">
    <title>Insert</title>
  </head>
  <body>

    <form action="" method="post">
      <label>NIM:</label>
        <input type="text" name="NIM" class="form-control">
          <label>NAMA:</label>
        <input type="text" name="NAMA" class="form-control">
          <label>PROGRAM STUDI:</label>
        <input type="text" name="PROGRAM_STUDI" class="form form-control">
        <label>JENIS KELAMIN:</label>
      <input type="text" name="JENIS_KELAMIN" class="form form-control">
      <label>TEMPAT LAHIR:</label>
    <input type="text" name="TEMPAT_LAHIR" class="form form-control">
    <label>NOMOR TELEPON:</label>
  <input type="text" name="NOMOR_TELEPON" class="form form-control">
        <button name="add" class="btn btn-danger">Submit</button>
    </form>


  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
